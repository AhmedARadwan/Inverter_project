//
// File: mppt_controller_.cpp
//
// Code generated for Simulink model 'mppt_controller_'.
//
// Model version                  : 1.15
// Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
// C/C++ source code generated on : Tue Feb 06 10:10:52 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "mppt_controller_.h"
#include "mppt_controller__private.h"

static void rate_scheduler(RT_MODEL_mppt_controller__T *const mppt_controller__M);

//
//   This function updates active task flag for each subrate.
// The function is called at model base rate, hence the
// generated code self-manages all its subrates.
//
static void rate_scheduler(RT_MODEL_mppt_controller__T *const mppt_controller__M)
{
  // Compute which subrates run during the next base time step.  Subrates
  //  are an integer multiple of the base rate counter.  Therefore, the subtask
  //  counter is reset when it reaches its limit (zero means run).

  (mppt_controller__M->Timing.TaskCounters.TID[1])++;
  if ((mppt_controller__M->Timing.TaskCounters.TID[1]) > 4) {// Sample time: [3.3333333333333335E-5s, 0.0s] 
    mppt_controller__M->Timing.TaskCounters.TID[1] = 0;
  }

  (mppt_controller__M->Timing.TaskCounters.TID[2])++;
  if ((mppt_controller__M->Timing.TaskCounters.TID[2]) > 14) {// Sample time: [0.0001s, 0.0s] 
    mppt_controller__M->Timing.TaskCounters.TID[2] = 0;
  }

  (mppt_controller__M->Timing.TaskCounters.TID[3])++;
  if ((mppt_controller__M->Timing.TaskCounters.TID[3]) > 99999) {// Sample time: [0.66666666666666663s, 0.0s] 
    mppt_controller__M->Timing.TaskCounters.TID[3] = 0;
  }
}

real_T rt_remd(real_T u0, real_T u1)
{
  real_T y;
  real_T u1_0;
  if (u1 < 0.0) {
    u1_0 = ceil(u1);
  } else {
    u1_0 = floor(u1);
  }

  if ((u1 != 0.0) && (u1 != u1_0)) {
    u1_0 = abs(u0 / u1);
    if (abs(u1_0 - floor(u1_0 + 0.5)) <= DBL_EPSILON * u1_0) {
      y = 0.0;
    } else {
      y = fmod(u0, u1);
    }
  } else {
    y = fmod(u0, u1);
  }

  return y;
}

// Model step function
void mppt_controller_ModelClass::step()
{
  real_T rtb_Product;
  real_T rtb_Sum;
  real_T rtb_Sum_e;
  real_T rtb_Fcn1;
  real_T rtb_Sum_h;
  if ((&mppt_controller__M)->Timing.TaskCounters.TID[2] == 0) {
    // Sum: '<S2>/Sum' incorporates:
    //   Fcn: '<S2>/SQR'
    //   Inport: '<Root>/PowSig'
    //   UnitDelay: '<S2>/Unit Delay'

    rtb_Sum = mppt_controller__U.PowSig * mppt_controller__U.PowSig +
      mppt_controller__DW.UnitDelay_DSTATE;

    // Product: '<S2>/Product' incorporates:
    //   DigitalClock: '<S2>/Digital Clock'
    //   Fcn: '<S2>/SQR1'
    //   Math: '<S2>/Elementary Math'
    //
    //  About '<S2>/Elementary Math':
    //   Operator: reciprocal

    rtb_Product = 1.0 / ((((&mppt_controller__M)->Timing.clockTick2) * 0.0001) /
                         0.0001 + 1.0) * rtb_Sum;

    // Math: '<S2>/SQRT'
    //
    //  About '<S2>/SQRT':
    //   Operator: sqrt

    if (rtb_Product < 0.0) {
      mppt_controller__B.SQRT = -sqrt(abs(rtb_Product));
    } else {
      mppt_controller__B.SQRT = sqrt(rtb_Product);
    }

    // End of Math: '<S2>/SQRT'
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[3] == 0) {
    // UnitDelay: '<S1>/Unit Delay'
    mppt_controller__B.UnitDelay = mppt_controller__DW.UnitDelay_DSTATE_g;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[1] == 0) {
    // Sum: '<S1>/Add1'
    rtb_Sum_h = mppt_controller__B.SQRT - mppt_controller__B.UnitDelay;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[2] == 0) {
    // Sum: '<S3>/Sum' incorporates:
    //   Fcn: '<S3>/SQR'
    //   Inport: '<Root>/VoltSig'
    //   UnitDelay: '<S3>/Unit Delay'

    rtb_Sum_e = mppt_controller__U.VoltSig * mppt_controller__U.VoltSig +
      mppt_controller__DW.UnitDelay_DSTATE_n;

    // Product: '<S3>/Product' incorporates:
    //   DigitalClock: '<S3>/Digital Clock'
    //   Fcn: '<S3>/SQR1'
    //   Math: '<S3>/Elementary Math'
    //
    //  About '<S3>/Elementary Math':
    //   Operator: reciprocal

    rtb_Product = 1.0 / ((((&mppt_controller__M)->Timing.clockTick2) * 0.0001) /
                         0.0001 + 1.0) * rtb_Sum_e;

    // Math: '<S3>/SQRT'
    //
    //  About '<S3>/SQRT':
    //   Operator: sqrt

    if (rtb_Product < 0.0) {
      mppt_controller__B.SQRT_l = -sqrt(abs(rtb_Product));
    } else {
      mppt_controller__B.SQRT_l = sqrt(rtb_Product);
    }

    // End of Math: '<S3>/SQRT'
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[3] == 0) {
    // UnitDelay: '<S1>/Unit Delay1'
    mppt_controller__B.UnitDelay1 = mppt_controller__DW.UnitDelay1_DSTATE;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[1] == 0) {
    // Sum: '<S1>/Add2'
    rtb_Product = mppt_controller__B.SQRT_l - mppt_controller__B.UnitDelay1;

    // Fcn: '<S1>/Fcn1'
    rtb_Fcn1 = (((real_T)((rtb_Sum_h >= 10.0) && (rtb_Product >= 2.0)) * 0.01 +
                 (real_T)((rtb_Sum_h < 10.0) && (rtb_Product < 2.0)) * 0.01) +
                (real_T)((rtb_Sum_h < 10.0) && (rtb_Product > 2.0)) * -0.01) +
      (real_T)((rtb_Sum_h >= 10.0) && (rtb_Product < 2.0)) * -0.01;

    // Sum: '<S4>/Sum' incorporates:
    //   Delay: '<S6>/UD'
    //   DiscreteIntegrator: '<S4>/Integrator'
    //   Sum: '<S6>/Diff'

    rtb_Product = (rtb_Fcn1 + mppt_controller__DW.Integrator_DSTATE) + (0.0 -
      mppt_controller__DW.UD_DSTATE);

    // Saturate: '<S4>/Saturate'
    if (rtb_Product > 0.4) {
      rtb_Product = 0.4;
    } else {
      if (rtb_Product < -0.4) {
        rtb_Product = -0.4;
      }
    }

    // End of Saturate: '<S4>/Saturate'

    // Sum: '<S1>/Add' incorporates:
    //   Constant: '<S1>/Dd'

    mppt_controller__B.Add = 0.5 + rtb_Product;
  }

  // Outport: '<Root>/Pulses_' incorporates:
  //   Constant: '<S7>/Constant'
  //   Constant: '<S9>/Constant2'
  //   DataTypeConversion: '<S5>/Data Type Conversion'
  //   DigitalClock: '<S9>/Digital Clock'
  //   Fcn: '<S5>/Fcn'
  //   Fcn: '<S9>/Fcn'
  //   Gain: '<S9>/1\ib1'
  //   Logic: '<S5>/Logical Operator'
  //   Math: '<S9>/Math Function'
  //   RelationalOperator: '<S5>/Relational Operator'
  //   RelationalOperator: '<S7>/Compare'

  mppt_controller__Y.Pulses_ = ((mppt_controller__B.Add != 0.0) &&
    (mppt_controller__B.Add >= ((5000.0 * rt_remd(((((&mppt_controller__M)
    ->Timing.clockTick0+(&mppt_controller__M)->Timing.clockTickH0* 4294967296.0))
    * 6.6666666666666666E-6), 0.0002) * 2.0 - 1.0) + 1.0) * 0.5));
  if ((&mppt_controller__M)->Timing.TaskCounters.TID[1] == 0) {
    // Outport: '<Root>/DutyCycle_'
    mppt_controller__Y.DutyCycle_ = mppt_controller__B.Add;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[2] == 0) {
    // Update for UnitDelay: '<S2>/Unit Delay'
    mppt_controller__DW.UnitDelay_DSTATE = rtb_Sum;

    // Update for UnitDelay: '<S3>/Unit Delay'
    mppt_controller__DW.UnitDelay_DSTATE_n = rtb_Sum_e;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[3] == 0) {
    // Update for UnitDelay: '<S1>/Unit Delay'
    mppt_controller__DW.UnitDelay_DSTATE_g = mppt_controller__B.SQRT;

    // Update for UnitDelay: '<S1>/Unit Delay1'
    mppt_controller__DW.UnitDelay1_DSTATE = mppt_controller__B.SQRT_l;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[1] == 0) {
    // Update for DiscreteIntegrator: '<S4>/Integrator'
    mppt_controller__DW.Integrator_DSTATE += 3.3333333333333335E-5 * rtb_Fcn1;

    // Update for Delay: '<S6>/UD'
    mppt_controller__DW.UD_DSTATE = 0.0;
  }

  // Update absolute time for base rate
  // The "clockTick0" counts the number of times the code of this task has
  //  been executed. The resolution of this integer timer is 6.6666666666666666E-6, which is the step size
  //  of the task. Size of "clockTick0" ensures timer will not overflow during the
  //  application lifespan selected.
  //  Timer of this task consists of two 32 bit unsigned integers.
  //  The two integers represent the low bits Timing.clockTick0 and the high bits
  //  Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.

  (&mppt_controller__M)->Timing.clockTick0++;
  if (!(&mppt_controller__M)->Timing.clockTick0) {
    (&mppt_controller__M)->Timing.clockTickH0++;
  }

  if ((&mppt_controller__M)->Timing.TaskCounters.TID[2] == 0) {
    // Update absolute timer for sample time: [0.0001s, 0.0s]
    // The "clockTick2" counts the number of times the code of this task has
    //  been executed. The resolution of this integer timer is 0.0001, which is the step size
    //  of the task. Size of "clockTick2" ensures timer will not overflow during the
    //  application lifespan selected.

    (&mppt_controller__M)->Timing.clockTick2++;
  }

  rate_scheduler((&mppt_controller__M));
}

// Model initialize function
void mppt_controller_ModelClass::initialize()
{
  // Registration code

  // initialize real-time model
  (void) memset((void *)(&mppt_controller__M), 0,
                sizeof(RT_MODEL_mppt_controller__T));

  // block I/O
  (void) memset(((void *) &mppt_controller__B), 0,
                sizeof(B_mppt_controller__T));

  // states (dwork)
  (void) memset((void *)&mppt_controller__DW, 0,
                sizeof(DW_mppt_controller__T));

  // external inputs
  (void)memset((void *)&mppt_controller__U, 0, sizeof(ExtU_mppt_controller__T));

  // external outputs
  (void) memset((void *)&mppt_controller__Y, 0,
                sizeof(ExtY_mppt_controller__T));
}

// Model terminate function
void mppt_controller_ModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
mppt_controller_ModelClass::mppt_controller_ModelClass()
{
}

// Destructor
mppt_controller_ModelClass::~mppt_controller_ModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_mppt_controller__T * mppt_controller_ModelClass::getRTM()
{
  return (&mppt_controller__M);
}

//
// File trailer for generated code.
//
// [EOF]
//
