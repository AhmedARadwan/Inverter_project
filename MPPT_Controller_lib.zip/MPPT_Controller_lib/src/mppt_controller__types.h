//
// File: mppt_controller__types.h
//
// Code generated for Simulink model 'mppt_controller_'.
//
// Model version                  : 1.11
// Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
// C/C++ source code generated on : Wed Jan 31 23:55:19 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_mppt_controller__types_h_
#define RTW_HEADER_mppt_controller__types_h_

// Forward declaration for rtModel
typedef struct tag_RTM_mppt_controller__T RT_MODEL_mppt_controller__T;

#endif                                 // RTW_HEADER_mppt_controller__types_h_

//
// File trailer for generated code.
//
// [EOF]
//
