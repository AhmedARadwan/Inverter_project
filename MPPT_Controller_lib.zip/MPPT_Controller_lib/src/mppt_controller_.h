//
// File: mppt_controller_.h
//
// Code generated for Simulink model 'mppt_controller_'.
//
// Model version                  : 1.15
// Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
// C/C++ source code generated on : Tue Feb 06 10:10:52 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_mppt_controller__h_
#define RTW_HEADER_mppt_controller__h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef mppt_controller__COMMON_INCLUDES_
# define mppt_controller__COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 // mppt_controller__COMMON_INCLUDES_

#include "mppt_controller__types.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

// Block signals (auto storage)
typedef struct {
  real_T SQRT;                         // '<S2>/SQRT'
  real_T UnitDelay;                    // '<S1>/Unit Delay'
  real_T SQRT_l;                       // '<S3>/SQRT'
  real_T UnitDelay1;                   // '<S1>/Unit Delay1'
  real_T Add;                          // '<S1>/Add'
} B_mppt_controller__T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  real_T UnitDelay_DSTATE;             // '<S2>/Unit Delay'
  real_T UnitDelay_DSTATE_g;           // '<S1>/Unit Delay'
  real_T UnitDelay_DSTATE_n;           // '<S3>/Unit Delay'
  real_T UnitDelay1_DSTATE;            // '<S1>/Unit Delay1'
  real_T Integrator_DSTATE;            // '<S4>/Integrator'
  real_T UD_DSTATE;                    // '<S6>/UD'
} DW_mppt_controller__T;

// External inputs (root inport signals with auto storage)
typedef struct {
  real_T VoltSig;                      // '<Root>/VoltSig'
  real_T PowSig;                       // '<Root>/PowSig'
} ExtU_mppt_controller__T;

// External outputs (root outports fed by signals with auto storage)
typedef struct {
  real_T Pulses_;                      // '<Root>/Pulses_'
  real_T DutyCycle_;                   // '<Root>/DutyCycle_'
} ExtY_mppt_controller__T;

// Real-time Model Data Structure
struct tag_RTM_mppt_controller__T {
  const char_T * volatile errorStatus;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    uint32_T clockTick2;
    struct {
      uint32_T TID[4];
    } TaskCounters;
  } Timing;
};

#ifdef __cplusplus

extern "C" {

#endif

#ifdef __cplusplus

}
#endif

// Class declaration for model mppt_controller_
class mppt_controller_ModelClass {
  // public data and function members
 public:
  // External inputs
  ExtU_mppt_controller__T mppt_controller__U;

  // External outputs
  ExtY_mppt_controller__T mppt_controller__Y;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  mppt_controller_ModelClass();

  // Destructor
  ~mppt_controller_ModelClass();

  // Real-Time Model get method
  RT_MODEL_mppt_controller__T * getRTM();

  // private data and function members
 private:
  // Block signals
  B_mppt_controller__T mppt_controller__B;

  // Block states
  DW_mppt_controller__T mppt_controller__DW;

  // Real-Time Model
  RT_MODEL_mppt_controller__T mppt_controller__M;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S6>/DTDup' : Unused code path elimination
//  Block '<S2>/Zero-Order Hold' : Eliminated since input and output rates are identical
//  Block '<S3>/Zero-Order Hold' : Eliminated since input and output rates are identical
//  Block '<S4>/Integral Gain' : Eliminated nontunable gain of 1
//  Block '<S4>/Proportional Gain' : Eliminated nontunable gain of 1
//  Block '<S1>/Gain' : Eliminated nontunable gain of 1


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'mppt_controller_'
//  '<S1>'   : 'mppt_controller_/MPPT_Controller'
//  '<S2>'   : 'mppt_controller_/MPPT_Controller/DRMS'
//  '<S3>'   : 'mppt_controller_/MPPT_Controller/DRMS1'
//  '<S4>'   : 'mppt_controller_/MPPT_Controller/Discrete PID Controller'
//  '<S5>'   : 'mppt_controller_/MPPT_Controller/PWM Generator (DC-DC)'
//  '<S6>'   : 'mppt_controller_/MPPT_Controller/Discrete PID Controller/Differentiator'
//  '<S7>'   : 'mppt_controller_/MPPT_Controller/PWM Generator (DC-DC)/Compare To Zero'
//  '<S8>'   : 'mppt_controller_/MPPT_Controller/PWM Generator (DC-DC)/Sawtooth Generator'
//  '<S9>'   : 'mppt_controller_/MPPT_Controller/PWM Generator (DC-DC)/Sawtooth Generator/Model'

#endif                                 // RTW_HEADER_mppt_controller__h_

//
// File trailer for generated code.
//
// [EOF]
//
